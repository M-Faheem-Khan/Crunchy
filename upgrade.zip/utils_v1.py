import time
import socket
from piCamera import PiCamera

class LocalDevice(object):
	def ip(self):
		'''
		Return the client ip just the last values of the full ip
		'''
		local_ip = str([l for l in ([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] if not ip.startswith("127.")][:1], [[(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]]) if l][0][0])[::-1]
		x = local_ip.index(".")
		local_ip = local_ip[:x][::-1]
		return str(local_ip)

class Client(object):
	def setup_camera(self, angle):
		# Set Camera Settings and start preview
		print("Setting Up Camera")
		try:
		    camera = PiCamera()
		    # Set resolution of images below
		    camera.resolution = (2592, 1944)
		    camera.iso = int(0)
		    camera.start_preview()
		except Exception as e:
		    print(e)
		    sys.exit(1)

		print("CAMERA PREVIEW STARTED")

		# set angle
		# get angle from pi_config
		with open("/home/pi/pi_config.json", "r") as f:
			angle = json.load(f)[angle]
		

		# GPIO - ROTATE TO ANGLE
		# Wait for the rotaion to be complete then return
		# SIMULATING SERVO ROTAION BY PAUSING THE THREAD FOR 3 SECONDS

		time.sleep(3)

	def take_picture(self, dir_name):
		print("GETTING FTP CONFIGURATIONS")
		# get the wait times from ftp_config
		ftp_configs = None
		with open("/home/pi/ftp_config.json", "r") as f:
			ftp_configs = json.load(f)

		# Server Info
		username = ftp_configs["username"]
		password = ftp_configs["password"]
		serverIp = ftp_configs["server_ip"]
		
		# Wait times
		w1 = ftp_configs["w1"]
		w2 = ftp_configs["w2"]
		w3 = ftp_configs["w3"]
		w4 = ftp_configs["w4"]

		path = "1.jpg"
		camera.capture(path)
		print("Picture Taken")

		time.sleep(w1)

		# GPOI - Relay On/OFF
		# SIMULATING ACTION BY PAUSING THE THREAD FOR 3 SECONDS
		time.sleep(3)

		time.sleep(w2)

		path = "2.jpg"
		camera.capture(path)
		print("Picture Taken")

		time.sleep(w3)

		# Upload image
		self.UploadImages(self, dir_name, server_ip, username, password)

		time.sleep(w4)

		# GPOI - Relay On/OFF
		# SIMULATING ACTION BY PAUSING THE THREAD FOR 3 SECONDS
		time.sleep(3)

	def UploadImages(self, dir_name, server_ip, username, password):
		# Looking for .jpg files
		images = [i for i in os.listdir(os.getcwd()) if i.endswith(".jpg")]

		if len(images) == 2:
			print("Uploading images to server")

			directory = "Production"
			# client_Name - dir to create and save files in

			# connecting to ftp server
			ftp = FTP(ftp_server_ip, user=username, passwd=password)
			print("LOGGED IN")

			for i in range(len(images)):
				# getting image name
				# i is just for dir name (1 and 2)
				img = images[i]
				# generating path
				path = "/%s/%s/%s.jpg/" % (directory, dir_name, LocalDevice().ip())
				# making necessary directories
				ftp.mkd(path)
				print("Moving to %s" % (path))
				# moving to dir to upload image
				ftp.cwd(path)
				# uploading image
				ftp.storbinary("STOR " + img, open(img, "rb"))
				print("File Uploaded: %s" % (img))

			# ending connection after uploading images
			ftp.quit()

		else:
			print("ERROR: No Pictures Found")