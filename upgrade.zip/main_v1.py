import os
import sys
import json
import socket
from utils import *
from datetime import datetime

print("Server Started")

# setting ip(localhost) & port to listen on
udp_ip = ""
udp_port = 5005

print("Binding to port %d" % (udp_port))

try:
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	sock.bind((udp_ip, udp_port))
except Exception as e:
	print("The following exception was raised while trying to bind to port %d:\n%s\n" % (udp_port, e))
	sys.exit(1) # exiting with an error

print("Server is Ready to recieve commands!")

while True:
	data, addr = sock.recvfrom(1024)
	data = data.decode("ASCII")
	with open(str(datetime.now().time()), "w") as f:
		f.write(str(data))
	print("Command Recieved: %s" % (data))
	local_ip = LocalDevice().ip() # returns local device ip as string
	print("IP: " + local_ip)
	if data[0] == "0" or data[:len(local_ip)] == local_ip:
		print("Performing Command")
		# clearing command
		# removing '0' or deviceIp from the front of the command
		if data[0] == "0":
			data = data[1:]
		else:
			data = data[len(local_ip):]
		print("Command: %s" % (data))

		if "take_picture" in data:
			angle = data[-1]
			dir_name = data[len("take_picture"):-1]
			Client().setup_camera(angle)
			Client().take_picture(dir_name)

		elif "pi_config" in data:
			# writing pi_config data to file
			data = data[len("pi_config"):]
			with open("/home/pi/pi_config.json", "w") as f:
				f.write(data)

		elif "ftp_config" in data:
			# casting data from unicode to ascii to json
			data = data[len("ftp_config"):].encode("ASCII")
			with open("/home/pi/ftp_config.json", "w") as f:
				f.write(data)


		elif "flash" in data:
			# getting the state for flash
			state = data[-1]
			if state == "0":
				# turning off flash
				os.system("sudo ./hub-ctrl -b 1 -d 2 -P 2 -p 0")
			else:
				# turning on flash
				os.system("sudo ./hub-ctrl -b 1 -d 2 -P 2 -p 1")

	else:
		print("Ignoring Command: Command is not intended for me!")
